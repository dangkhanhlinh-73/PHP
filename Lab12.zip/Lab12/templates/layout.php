<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Include Bootstrap CSS via CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>CRUD App</title>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container">
            <a class="navbar-brand" href="/index.php">CRUD App</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="/index.php">Home</a>
                    </li>
                </ul>
                <div class="d-flex">
                    <!-- Kiểm tra xem người dùng đã đăng nhập chưa -->
                    <?php if (isset($_SESSION['username'])): ?>
                        <!-- Nếu đã đăng nhập, hiển thị nút Chào! và Logout -->
                        <a href="#" class="btn btn-outline-primary me-2">Chào! <?= htmlspecialchars($_SESSION['username']); ?></a>
                        <a href="/user/logout" class="btn btn-outline-danger">Logout</a>
                    <?php else: ?>
                        <!-- Nếu chưa đăng nhập, hiển thị nút Login -->
                        <a href="/user/login" class="btn btn-outline-primary">Login</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mt-3">
        <?= $content ?>
    </div>

    <!-- Include Bootstrap JS and Popper.js via CDN (required for Bootstrap JavaScript features) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
