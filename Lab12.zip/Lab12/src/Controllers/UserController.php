<?php

namespace App\Controllers;

use App\Controller;
use App\Models\User;

class UserController extends Controller
{
    private $userModel;

    public function __construct()
    {
        $this->userModel = new User();
    }

    public function index()
    {
        // Fetch all posts and display them in a view
        $users = $this->userModel->getAllUsers();

        $this->render('users\user-list', ['users' => $users]);
    }

    public function show($id)
    {
        
        $user = $this->userModel->getUserById($id);

        $this->render('users\user-form', ['user' => $user]);

    }

    public function create()
    {
        // Handle form submission to create a new post
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Retrieve form data
            $username = $_POST['username'];
            $firstname = $_POST['firstname'];
            $lastname = $_POST['lastname'];
            $password_input = $_POST['password_input'];
            $password_check = $_POST['password_check'];
            $email = $_POST['email'];
            
            if ($this->userModel->isUsernameExists($username)) {
                // Gửi thông báo lỗi đến view
                $error = "Username bị trùng !!!";
                $this->render('users\user-form', ['user' => compact('username', 'firstname', 'lastname', 'email'), 'error' => $error]);
                return;
            }
            
            // Kiểm tra mật khẩu xác nhận
            if ($password_input !== $password_check) {
                $error = "Mật khẩu không trùng !!!";
                $this->render('users\user-form', ['user' => compact('username', 'firstname', 'lastname', 'email'), 'error' => $error]);
                return;
            }

            // Call the model to create a new post
            $this->userModel->createUser($username , $firstname, $lastname ,$password_input ,$password_check ,$email);
        }

        // Display the form to create a new post
        
        $this->render('users\user-form', ['user' => []]);

    }

    public function update($id)
    {
        // Handle form submission to update a post
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Retrieve form data
            $username = $_POST['username'];
            $firstname = $_POST['firstname'];
            $lastname = $_POST['lastname'];
            $password_input = $_POST['password_input'];
            $password_check = $_POST['password_check'];
            $email = $_POST['email'];
            
            // Call the model to update the post
            $this->userModel->updateUser($id, $username , $firstname, $lastname ,$password_input ,$password_check ,$email);
            $_SESSION['message'] = "User $username cập nhật thành công";
        }

        // Fetch the post data and display the form to update
        $user = $this->userModel->getUserById($id);
        
        $this->render('users\user-form', ['user' => $user]);
    }

    public function delete($id)
    {
        $this->userModel->deleteUser($id);
        
        $_SESSION['message'] = "Xóa thành công user có ID: {$id}";
        
        header('Location: /index.php');
        
    }

    public function login()
    {
        // Xử lý đăng nhập
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = $_POST['username'];
            $password_input = $_POST['password'];

            $result = $this->userModel->login($username, $password_input);

            if ($result['success']) {
                $_SESSION['user_id'] = $this->userModel->getUserByUsername($username)['id'];
                $_SESSION['username'] = $username;
                $_SESSION['message'] = $result['message'];
                header('Location: /index.php');
                exit;
            } else {
                $this->render('users\user-login', ['error' => $result['message']]);
                return;
            }
        }

        // Hiển thị form đăng nhập
        $this->render('users\user-login', []);
    }

    public function register()
{
    // Xử lý đăng ký
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $username = $_POST['username'];
        $firstname = $_POST['firstname'];
        $lastname = $_POST['lastname'];
        $password_input = $_POST['password_input'];
        $password_check = $_POST['password_check'];
        $email = $_POST['email'];

        // Kiểm tra mật khẩu có khớp không
        if ($password_input !== $password_check) {
            $error = "Mật khẩu không khớp!";
            $this->render('users\user-register', ['error' => $error]);
            return;
        }

        // Kiểm tra độ dài mật khẩu
        // if (strlen($password_input) < 6) {
        //     $error = "Mật khẩu phải có ít nhất 6 ký tự!";
        //     $this->render('users\user-register', ['error' => $error]);
        //     return;
        // }

        // Kiểm tra định dạng email
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = "Email không hợp lệ!";
            $this->render('users\user-register', ['error' => $error]);
            return;
        }

        // Gọi phương thức model để đăng ký người dùng
        $result = $this->userModel->register($username, $firstname, $lastname, $password_input, $password_check, $email);

        if ($result['success']) {
            $_SESSION['message'] = "Đăng ký thành công! Vui lòng đăng nhập.";
            header('Location: /index.php?action=login');
            exit;
        } else {
            $this->render('users\user-register', ['error' => $result['message']]);
        }
    }

    // Hiển thị form đăng ký
    $this->render('users\user-register', []);
}


    public function logout()
    {
        // Xử lý đăng xuất
        session_destroy();
        header('Location: /index.php');
        exit;
    }
}