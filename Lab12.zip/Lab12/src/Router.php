<?php
namespace App;
use App\Controller\UserController;

class Router {
    private $routes = [];

    public function addRoute($pattern, $callback) {
        $this->routes[$pattern] = $callback;
    }
    
    public function match($uri) {
        // Sort routes by specificity (longer patterns first)
        // Sắp xếp các đường dẫn khớp nhiều nhất ưu tiên trước
        uksort($this->routes, function ($a, $b) {
            return strlen($b) - strlen($a);
        });

        foreach ($this->routes as $pattern => $callback) {
            // preg_match so pattern và uri khớp mẫu nhiều nhất rồi trả về matches
            if (preg_match($pattern, $uri, $matches)) {
                // array_shift là lấy phần cuối của matches và dưới dạng 'string'
                array_shift($matches); // Remove the full match
                // call_user_func_array  
                call_user_func_array($callback, $matches);
                return;
            }
        }
    }
}