<?php ob_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User List</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f9f9f9;
        }
        h1 {
            text-align: center;
            color: #333;
        }
        .message {
            width: 80%;
            margin: 10px auto;
            padding: 10px;
            border: 1px solid #4CAF50;
            background-color: #d4edda;
            color: #155724;
            border-radius: 5px;
            text-align: center;
        }
        .user-list {
            width: 80%;
            margin: 0 auto;
            border-collapse: collapse;
        }
        .user-list th, .user-list td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        .user-list th {
            background-color: #4CAF50;
            color: white;
        }
        .user-list tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        .user-list tr:hover {
            background-color: #ddd;
        }
        .action-links a {
            margin: 0 5px;
            text-decoration: none;
            color: #007BFF;
        }
        .action-links a:hover {
            color: #0056b3;
            text-decoration: underline;
        }
        .add-user {
            display: block;
            width: 150px;
            margin: 20px auto;
            text-align: center;
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .add-user:hover {
            background-color: #45a049;
        }
        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }
        .pagination a {
            display: inline-block;
            margin: 0 5px;
            padding: 8px 15px;
            text-decoration: none;
            color: #007BFF;
            background-color: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 5px;
            font-size: 14px;
            transition: all 0.3s ease;
        }
        .pagination a:hover {
            background-color: #007BFF;
            color: white;
        }
        .pagination a.active {
            background-color: #007BFF;
            color: white;
            font-weight: bold;
            border: 1px solid #007BFF;
        }
    </style>
    <script>
        function confirmDelete(url) {
            if (confirm("Are you sure you want to delete this user?")) {
                window.location.href = url;
            }
        }
    </script>
</head>
<body>
    <h1>User List</h1>
    
    <?php 
        if (isset($_SESSION['message'])): ?>
            <div class="message">
                <?= htmlspecialchars($_SESSION['message']) ?>
            </div>
        <?php unset($_SESSION['message']); ?>
    <?php endif; ?>

    <?php
        // Số lượng người dùng trên mỗi trang
        $usersPerPage = 10;

        // Tổng số người dùng
        $totalUsers = isset($users) ? count($users) : 0;
        
        // Tính số trang
        $totalPages = ceil($totalUsers / $usersPerPage);

        // Trang hiện tại
        $currentPage = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $currentPage = max(1, min($currentPage, $totalPages));

        // Lấy danh sách người dùng của trang hiện tại
        $currentUsers = $totalUsers > 0 
            ? array_slice($users, ($currentPage - 1) * $usersPerPage, $usersPerPage)
            : [];
    ?>

    <?php if ($totalUsers > 0): ?>
        <table class="user-list">
            <thead>
                <tr>
                    <th>STT</th>
                    <th>Username</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($currentUsers as $index => $user): ?>
                    <tr>
                        <td><?= ($currentPage - 1) * $usersPerPage + $index + 1 ?></td>
                        <td>
                            <a href="/user/show/<?= htmlspecialchars($user['id']) ?>">
                                <?= htmlspecialchars($user['username']) ?>
                            </a>
                        </td>
                        <td class="action-links">
                            <a href="/user/update/<?= htmlspecialchars($user['id']) ?>">Edit</a>
                            <a>|</a>
                            <a href="javascript:void(0);" 
                               onclick="confirmDelete('/user/delete/<?= htmlspecialchars($user['id']) ?>')">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p style="text-align: center; color: #555;">No users found.</p>
    <?php endif; ?>

    <!-- Phân trang -->
    <div class="pagination">
        <?php if ($currentPage > 1): ?>
            <a href="/index.php?page=<?= $currentPage - 1 ?>" class="prev">&laquo; Previous</a>
        <?php endif; ?>

        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
            <a href="/index.php?page=<?= $i ?>" 
               class="<?= $i == $currentPage ? 'active' : '' ?>">
                <?= $i ?>
            </a>
        <?php endfor; ?>

        <?php if ($currentPage < $totalPages): ?>
            <a href="/index.php?page=<?= $currentPage + 1 ?>" class="next">Next &raquo;</a>
        <?php endif; ?>
    </div>

    <a href="/user/create" class="add-user">Add User</a>
</body>
</html>
<?php $content = ob_get_clean(); ?>
<?php include (__DIR__ . '/../../../templates/layout.php'); ?>
