<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng Ký</title>
    <style>
        /* Dùng lại CSS từ phần Login */
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #4a90e2, #357ab8);
            background-color: #f4f4f9;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .form-container {
            background-color: #fff;
            padding: 30px 40px; /* Thêm padding đẹp mắt */
            border-radius: 12px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 100%;
            transform: translateY(-30px);
            opacity: 0;
            animation: fadeIn 0.5s forwards;
        }

        .form-container h1 {
            text-align: center;
            color: #333;
            font-size: 24px;
            margin-bottom: 20px;
        }

        .form-container label {
            font-weight: bold;
            color: #555;
            margin-bottom: 8px;
            display: block;
        }

        .form-container input {
            width: 100%; /* Chiều rộng 100% để ô nhập bằng với nút */
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box; /* Bao gồm padding và border trong width */
        }

        .form-container input:focus {
            border-color: #4a90e2;
            outline: none;
        }

        .form-container button {
            background-color: #4a90e2;
            color: #fff;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%; /* Chiều rộng 100% cho nút */
            font-size: 16px;
        }

        .form-container button:hover {
            background-color: #357ab8;
        }

        .form-container a {
            text-align: center;
            display: block;
            margin-top: 10px;
            color: #4a90e2;
            text-decoration: none;
        }

        .form-container a:hover {
            text-decoration: underline;
        }

        .form-container p {
            color: red;
            text-align: center;
            font-size: 14px;
        }

        /* Thêm hiệu ứng fade-in cho form */
        @keyframes fadeIn {
            0% {
                opacity: 0;
                transform: translateY(-30px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h1>Đăng Ký</h1>
        <?php if (!empty($error)): ?>
            <p><?php echo $error; ?></p>
        <?php endif; ?>
        <form method="POST">
            <label for="username">Tên Đăng Nhập</label>
            <input type="text" name="username" id="username" required>

            <label for="firstname">Họ</label>
            <input type="text" name="firstname" id="firstname" required>

            <label for="lastname">Tên</label>
            <input type="text" name="lastname" id="lastname" required>

            <label for="email">Email</label>
            <input type="email" name="email" id="email" required>

            <label for="password">Mật Khẩu</label>
            <input type="password" name="password_input" id="password" required>

            <label for="password_check">Xác Nhận Mật Khẩu</label>
            <input type="password" name="password_check" id="password_check" required>

            <button type="submit">Đăng Ký</button>
        </form>
        <a href="/index.php?action=login">Đã có tài khoản? Đăng nhập ngay</a>
    </div>
</body>
</html>
