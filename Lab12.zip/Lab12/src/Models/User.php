<?php

namespace App\Models;
//require_once(__DIR__ . '/../../config.php');

class User
{
    private $connection;

    public function __construct()
    {
        // Replace these values with your actual database configuration
        $host = DB_HOST;
        $username = DB_USER;
        $password = DB_PASSWORD;
        $database = DB_NAME;

        $this->connection = new \mysqli($host, $username, $password, $database);

        // Check connection
        if ($this->connection->connect_error) {
            die("Connection failed: " . $this->connection->connect_error);
        }
    }

    public function getAllUsers()
    {
        $result = $this->connection->query("SELECT * FROM users");
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function getUserById($id)
    {
        $postId = $this->connection->real_escape_string($id);
        $result = $this->connection->query("SELECT * FROM users WHERE id = $id");

        return $result->fetch_assoc();
    }

    public function createUser($username , $firstname, $lastname ,$password_input ,$password_check ,$email)
    {
        $username = $this->connection->real_escape_string($username);
        $firstname = $this->connection->real_escape_string($firstname);
        $lastname = $this->connection->real_escape_string($lastname);
        $password_input = $this->connection->real_escape_string($password_input);
        $password_check = $this->connection->real_escape_string($password_check);
        $email = $this->connection->real_escape_string($email);

        $this->connection->query("INSERT INTO users (username, 
                                                            firstname, 
                                                            lastname,
                                                            password_input,
                                                            password_check,
                                                            email)
                                        VALUES ('$username', 
                                                '$firstname', 
                                                '$lastname',
                                                '$password_input',
                                                '$password_check',
                                                '$email')");
        
        // Redirect to the index page after creating post
        header('Location: ../../index.php');
    }

    public function updateUser($id, $username , $firstname, $lastname ,$password_input ,$password_check ,$email)
    {
        $id = $this->connection->real_escape_string($id);
        $username = $this->connection->real_escape_string($username);
        $firstname = $this->connection->real_escape_string($firstname);
        $lastname = $this->connection->real_escape_string($lastname);
        $password_input = $this->connection->real_escape_string($password_input);
        $password_check = $this->connection->real_escape_string($password_check);
        $email = $this->connection->real_escape_string($email);
        

        $this->connection->query("UPDATE users SET username='$username', 
                                                          firstname='$firstname', 
                                                          lastname='$lastname', 
                                                          password_input='$password_input', 
                                                          password_check='$password_check', 
                                                          email='$email' 
                                                    WHERE id=$id");
        
        // Redirect to the index page after update
        header('Location: ../../index.php');
    }

    public function deleteUser($id)
    {
        $postId = $this->connection->real_escape_string($id);
        $this->connection->query("DELETE FROM users WHERE id=$id");
    }

    public function isUsernameExists($username)
    {
        $sql = "SELECT COUNT(*) as count FROM users WHERE username = ?";
        $stmt = $this->connection->prepare($sql);
        $stmt->bind_param('s', $username); // 's' chỉ định kiểu dữ liệu là string
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();

        return $row['count'] > 0;
    }

    public function getUserByUsername($username)
    {
        $sql = "SELECT * FROM users WHERE username = ?";
        $stmt = $this->connection->prepare($sql);
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }

    public function login($username, $password)
    {
        // Lấy thông tin người dùng từ cơ sở dữ liệu
        $sql = "SELECT id, username, password_input FROM users WHERE username = ?";
        $stmt = $this->connection->prepare($sql);
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        // Kiểm tra nếu không tìm thấy người dùng
        if (!$user) {
            return ['success' => false, 'message' => 'Tên đăng nhập không tồn tại.'];
        }

        // Xác thực mật khẩu (đảm bảo password đã được mã hóa khi lưu vào DB)
        if ($password === $user['password_input']) {
            // Đăng nhập thành công, lưu thông tin người dùng vào session

            // Đảm bảo session là an toàn
            session_regenerate_id(true); // Sử dụng session mới để tránh session fixation

            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];

            return ['success' => true, 'message' => 'Đăng nhập thành công.'];
        } else {
            return ['success' => false, 'message' => 'Sai mật khẩu.'];
        }
    }



    public function register($username, $firstname, $lastname, $password_input, $password_check, $email)
    {
        // Kiểm tra nếu username hoặc email đã tồn tại
        $sql = "SELECT COUNT(*) as count FROM users WHERE username = ? OR email = ?";
        $stmt = $this->connection->prepare($sql);
        $stmt->bind_param('ss', $username, $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();

        if ($row['count'] > 0) {
            return ['success' => false, 'message' => 'Username hoặc Email đã tồn tại.'];
        }

        // Thêm người dùng vào cơ sở dữ liệu với mật khẩu đã mã hóa
        $sql = "INSERT INTO users (username, firstname, lastname, password_input, password_check, email) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $this->connection->prepare($sql);
        $stmt->bind_param('ssssss', $username, $firstname, $lastname, $password_input, $password_check, $email);
        
        if ($stmt->execute()) {
            return ['success' => true, 'message' => 'Đăng ký thành công.'];
        } else {
            return ['success' => false, 'message' => 'Lỗi khi đăng ký người dùng.'];
        }
    }



}
