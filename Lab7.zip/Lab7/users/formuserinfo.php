<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
    <?php 
    if (isset($_GET['id']) && $_GET['id'] == 0) {
        echo "Create User"; 
    } else {
        echo "Update User";
    }
    ?>
    </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<style>
     .user-info {
        background-color: #f8f9fa;
        border-radius: 5px; 
        padding: 20px; 
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2); 
        margin-top: 20px;
        max-width: 600px;
        min-height: 600px; /* Tạo chiều dài theo dọc */
        margin-left: auto;
        margin-right: auto;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
    }

    h2 {
        text-align: center; /* Căn giữa tiêu đề */
    }

    .button-group {
        display: flex;
        justify-content: space-between;
        margin-top: 20px;
    }
</style>
<body>
<div class="cxontainer mt-5">
<?php
include '../includes/opening.php'; // Kết nối đến cơ sở dữ liệu
include '../includes/functions.php';

if (isset($_GET['id'])) {
    $users = loadUsers($conn);
    $id = $_GET['id'];
    $foundID = false;

    if($id == 0) {
        // Form tạo người dùng mới
        ?>
        <div class="user-info">
            <h2>Create User</h2>
            <form action="../controllers/user_controller.php" method="POST">
                <input type="hidden" name="user_id" value="0" />
                <div class="mb-3">
                    <label for="username" class="form-label">User Name</label>
                    <input type="text" class="form-control" id="username" name="username" value="" required>
                </div>

                <?php if (isset($_GET['error'])): ?>
                    <div class="text-danger"><?php echo $_GET['error']; ?></div>
                <?php endif; ?>

                <div class="mb-3">
                    <label for="firstname" class="form-label">First Name</label>
                    <input type="text" class="form-control" id="firstname" name="firstname" value="" required>
                </div>

                <div class="mb-3">
                    <label for="lastname" class="form-label">Last Name</label>
                    <input type="text" class="form-control" id="lastname" name="lastname" value="" required>
                </div>

                <div class="mb-3">
                    <label for="password_input" class="form-label">Password</label>
                    <input type="password" class="form-control" id="password_input" name="password_input" value="" required>
                </div>

                <div class="mb-3">
                    <label for="password_check" class="form-label">Confirm Password</label>
                    <input type="password" class="form-control" id="password_check" name="password_check" value="" required>
                </div>

                <div class="mb-3">
                    <label for="primary_email" class="form-label">Primary Email</label>
                    <input type="email" class="form-control" id="primary_email" name="primary_email" value="" required>
                </div>
                <div class="button-group">
                        <button type="submit" class="btn btn-success" name="btnCreateUser" value="Create" style="background-color: #28a745">Create</button>
                        <a href="users.php" class="btn btn-primary">Quay về</a>
                </div>
            </form>
        </div>
        <?php
    } else {
        foreach($users as $user) {
            if($user->getUserID() == $id){
                $foundID = true;
                // Hiển thị thông tin người dùng để chỉnh sửa
                ?>
                <div class="user-info">
                    <h2>Edit User</h2>
                    <form action="../controllers/user_controller.php" method="POST">
                        <input type="hidden" name="user_id" value="<?php echo $user->getUserID(); ?>" />
                        <div class="mb-3">
                            <label for="username" class="form-label">User Name</label>
                            <input type="text" class="form-control" id="username" name="username" value="<?php echo $user->getUserName(); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="firstname" class="form-label">First Name</label>
                            <input type="text" class="form-control" id="firstname" name="firstname" value="<?php echo $user->getFirstName(); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="lastname" class="form-label">Last Name</label>
                            <input type="text" class="form-control" id="lastname" name="lastname" value="<?php echo $user->getLastName(); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="password_input" class="form-label">Password</label>
                            <input type="password" class="form-control" id="password_input" name="password_input" value="<?php echo $user->getPasswordInput(); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="password_check" class="form-label">Confirm Password</label>
                            <input type="password" class="form-control" id="password_check" name="password_check" value="<?php echo $user->getPasswordCheck(); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="primary_email" class="form-label">Primary Email</label>
                            <input type="email" class="form-control" id="primary_email" name="primary_email" value="<?php echo $user->getPrimaryEmail(); ?>" required>
                        </div>

                        <div class="button-group">
                                <button type="submit" class="btn btn-success" name="btnUpdateUser" value="Update" style="background-color: #28a745">Update</button>
                                <a href="users.php" class="btn btn-primary">Quay về</a>
                        </div>
                    </form>
                </div>
                <?php
                break;
            }
        }
        
        if (!$foundID) {
            echo "User not found.";
        }
    }
} else {
    echo "No user ID provided.";
}
?>

</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>