<?php
$server = "localhost";
$username = "root";
$password = "1234";  
$schema = "users_schema"; 

$conn = new mysqli($server, $username, $password, $schema);

if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

?>