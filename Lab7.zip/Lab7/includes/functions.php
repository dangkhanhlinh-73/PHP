<?php
include 'user.php';
include '../includes/opening.php';
function loadUsers($conn) {
    $sql = "SELECT * FROM users";
    $result = $conn->query($sql);

    $users = array();
    
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $user = new User(
                $row['id'],
                $row['username'],
                $row['firstname'],
                $row['lastname'],
                $row['password_input'],
                $row['password_check'],
                $row['email']
            );
            $users[] = $user;
        }
    }else{
        echo "Không có người dùng nào !!!";
    }
    return $users;
}

function displayUsersWithLinkToForm($conn){
    $users = loadUsers($conn);
    
    echo '<table class="table table-striped table-bordered table-hover" style="width: 50%; margin: auto; font-size: 35px; border: 1px solid #ccc; border-radius: 1px; box-shadow: 0px 0px 0px 5px rgba(0, 0, 0, 1);">';  
    echo '<thead class="table-dark">';
    echo '<tr>';
    echo '<th scope="col" class="text-center">Username</th>';
    echo '</tr>';
    echo '</thead>';
    
    foreach ($users as $user) {
        echo '<tr>';
        echo '<td class="text-center"><a href="formuserinfo.php?id=' . $user->getUserID() . '" style="font-size: inherit;">' . $user->getUserName() . '</a></td>';
        echo '</tr>';
    }
    echo '<tr><td colspan="2" class="text-end">';
    echo '<a href="formuserinfo.php?id=0" class="btn btn-primary" style="font-size: 25px" role="button">Create</a>';
    echo '</td></tr>';
    echo '</table>';
}

?>