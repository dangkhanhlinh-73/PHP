<?php
require_once('../includes/functions.php');
require_once('../includes/user.php');
require_once('../includes/opening.php'); // Thêm kết nối đến cơ sở dữ liệu

if(isset($_POST["user_id"])){
    $id = intval($_POST["user_id"]);
    
    $error = "";
    
    $users = loadUsers($conn);
    $userUPD = [];
    
    // update
    if($id != 0){
        foreach($users as $user){
            if($user->getUserID() == $id){
                $username = trim($_POST['username']);
                $firstname = trim($_POST['firstname']);
                $lastname = trim($_POST['lastname']);
                $passwordInput = trim($_POST['password_input']);
                $passwordCheck = trim($_POST['password_check']);
                $primaryEmail = trim($_POST['primary_email']);

                // Cập nhật thông tin người dùng vào cơ sở dữ liệu
                $stmt = $conn->prepare("UPDATE users SET username=?, firstname=?, lastname=?, password_input=?, password_check=?, email=? WHERE id=?");

                // Liên kết các biến đã được tạo
                $stmt->bind_param("ssssssi", 
                    $username, 
                    $firstname, 
                    $lastname, 
                    $passwordInput, 
                    $passwordCheck,
                    $primaryEmail, 
                    $id // Đây là id kiểu int
                );
                if (!$stmt->execute()) {
                    // Xử lý lỗi nếu có
                    $error = "Có lỗi xảy ra trong quá trình cập nhật: " . $stmt->error;
                }else{
                    header('Location: ../users/users.php?success=');
                    exit();
                }
                $stmt->close();
            }
            $userUPD[] = $user;
        }
    }
    // create
    else{
        $newID = 0;
        $usernames = [];
        
        foreach ($users as $user) {
            if ($user->getUserID() > $newID) {
                $newID = $user->getUserID();
            }
            $usernames[] = $user->getUserName();
        }

        $newID++;

        $username = trim($_POST['username']);
        $firstname = trim($_POST['firstname']);
        $lastname = trim($_POST['lastname']);
        $passwordInput = trim($_POST['password_input']);
        $passwordCheck = trim($_POST['password_check']);
        $primaryEmail = trim($_POST['primary_email']);

        if (in_array(trim($_POST['username']), $usernames)) {
            header('Location: ../users/formuserinfo.php?id=0&error=' . urlencode("Username đã tồn tại. Vui lòng chọn username khác!"));
            exit();
        }

        $newUser = new User(
        $newID, 
        $username,
        $firstname,
        $lastname,
        $passwordInput,
        $passwordCheck,
        $primaryEmail
        );

        // Thêm người dùng mới vào cơ sở dữ liệu
        $stmt = $conn->prepare("INSERT INTO users (id, username, firstname, lastname, password_input, password_check, email) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("issssss", 
        $newID, 
        $username,
            $firstname,
            $lastname,
            $passwordInput,
            $passwordCheck,
            $primaryEmail
        );
        if (!$stmt->execute()) {
            $error = "Có lỗi xảy ra trong quá trình thêm người dùng: " . $stmt->error;
        }else{
            header('Location: ../users/users.php?success=');
            exit();
        }
        $stmt->close();

        $userUPD = $users;
        $userUPD[] = $newUser;
    }
}
?>
