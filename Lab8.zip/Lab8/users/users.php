<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User List</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
    <h1 class="text-center mb-4" style="font-size: 70px">User List</h1>
    <?php
    include '../includes/functions.php';
    include '../includes/opening.php';
    displayUsersWithLinkToForm($conn);
    ?>
    <br><br>
    <h1>Users from DB</h1>
    <?php
    display_users($conn);
    ?>
    <br><br>
    <h1>Delete</h1>
    <?php
    display_users_with_action($conn, "user_controller.php?delete_user_id=", "Delete");
    //displayUsers();
    ?>
    <br><br><br><br> 
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>