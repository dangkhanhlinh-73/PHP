<?php
include 'user.php';
include '../includes/opening.php';
function loadUsers($conn) {
    $sql = "SELECT * FROM users";
    $result = $conn->query($sql);

    $users = array();
    
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $user = new User(
                $row['id'],
                $row['username'],
                $row['firstname'],
                $row['lastname'],
                $row['password_input'],
                $row['password_check'],
                $row['email']
            );
            $users[] = $user;
        }
    }else{
        echo "Không có người dùng nào !!!";
    }
    return $users;
}

function display_users($conn) {

    $query = "SELECT * FROM users";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 0) {
        echo "No data";
    } else {
        echo '<table class="table table-striped table-bordered table-hover" style="width: 50%; margin: auto; font-size: 35px; border: 1px solid #ccc; border-radius: 1px; box-shadow: 0px 0px 0px 5px rgba(0, 0, 0, 1);">';  
        echo '<thead class="table-dark">';
        echo '<tr>';
        echo '<th scope="col" class="text-center">ID</th>';
        echo '<th scope="col" class="text-center">Username</th>';
        echo '<th scope="col" class="text-center">Firstname</th>';
        echo '<th scope="col" class="text-center">Lastname</th>';
        echo '<th scope="col" class="text-center">Email</th>';
        echo '</tr>';
        echo '</thead>';
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>
                    <td>{$row['id']}</td>
                    <td>{$row['username']}</td>
                    <td>{$row['firstname']}</td>
                    <td>{$row['lastname']}</td>
                    <td>{$row['email']}</td>
                  </tr>";
        
        }
        echo "</table>";
    }
}

function display_users_with_action($conn, $query_string, $action_text) {
    if (isset($_GET['deleted_id'])) {
        $deleted_id = htmlspecialchars($_GET['deleted_id']);
        echo "<p style='text-align: center; color: green; font-size: 20px;'>Đã xóa người dùng với ID: $deleted_id</p>";
    }
    $query = "SELECT * FROM users";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 0) {
        echo "No data";
    } else {
        
        echo '<table class="table table-striped table-bordered table-hover" style="width: 50%; margin: auto; font-size: 35px; border: 1px solid #ccc; border-radius: 1px; box-shadow: 0px 0px 0px 5px rgba(0, 0, 0, 1);">';  
        echo '<thead class="table-dark">';
        echo '<tr>';
        echo '<th scope="col" class="text-center">ID</th>';
        echo '<th scope="col" class="text-center">Username</th>';
        echo '<th scope="col" class="text-center">Firstname</th>';
        echo '<th scope="col" class="text-center">Lastname</th>';
        echo '<th scope="col" class="text-center">Email</th>';
        echo '<th scope="col" class="text-center">Action</th>';
        echo '</tr>';
        echo '</thead>';
        while ($row = mysqli_fetch_assoc($result)) {
            $delete_link = "../controllers/{$query_string}{$row['id']}";
            echo "<tr>
                    <td>{$row['id']}</td>
                    <td>{$row['username']}</td>
                    <td>{$row['firstname']}</td>
                    <td>{$row['lastname']}</td>
                    <td>{$row['email']}</td>
                    <td><a href='{$delete_link}'>{$action_text}</a></td>
                  </tr>";
        }
        echo "</table>";
        
    }
    
}


function displayUsersWithLinkToForm($conn){
    $users = loadUsers($conn);
    
    echo '<table class="table table-striped table-bordered table-hover" style="width: 50%; margin: auto; font-size: 35px; border: 1px solid #ccc; border-radius: 1px; box-shadow: 0px 0px 0px 5px rgba(0, 0, 0, 1);">';  
    echo '<thead class="table-dark">';
    echo '<tr>';
    echo '<th scope="col" class="text-center">Username</th>';
    echo '</tr>';
    echo '</thead>';
    
    foreach ($users as $user) {
        echo '<tr>';
        echo '<td class="text-center"><a href="formuserinfo.php?id=' . $user->getUserID() . '" style="font-size: inherit;">' . $user->getUserName() . '</a></td>';
        echo '</tr>';
    }
    echo '<tr><td colspan="2" class="text-end">';
    echo '<a href="formuserinfo.php?id=0" class="btn btn-primary" style="font-size: 25px" role="button">Create</a>';
    echo '</td></tr>';
    echo '</table>';
}

?>