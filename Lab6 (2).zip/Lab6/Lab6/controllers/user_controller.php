<?php


$csvPath = __DIR__ . '/../data/users.csv';
$tempPath = __DIR__ . '/../data/temp_users.csv';


$user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
$firstname = isset($_POST['firstname']) ? trim($_POST['firstname']) : '';
$lastname = isset($_POST['lastname']) ? trim($_POST['lastname']) : '';
$username = isset($_POST['username']) ? trim($_POST['username']) : '';
$password = isset($_POST['password_input']) ? $_POST['password_input'] : '';
$password_check = isset($_POST['password_check']) ? $_POST['password_check'] : '';
$primary_email = isset($_POST['primary_email']) ? trim($_POST['primary_email']) : '';

if ($password !== $password_check) {
    die('Mật khẩu không khớp. <a href="../users/formuserinfo.php?id=' . $user_id . '">Quay lại</a>');
}


$users = [];
if (file_exists($csvPath) && ($fp = fopen($csvPath, 'r')) !== false) {
    while (($row = fgetcsv($fp, 0, ',', '"', '\\')) !== false) {
        if (count($row) >= 6) {
            $users[] = $row; // row: [user_id, username, firstname, lastname, password, primary_email]
        }
    }
    fclose($fp);
}

if (isset($_POST['btnUpdateUser'])) {
    
    if ($user_id === 0) {
        die('User không tồn tại. Bạn cần tạo user mới.');
    }

    
    if (($fp_temp = fopen($tempPath, 'w')) === false) {
        die('Không thể mở file temp để ghi.');
    }

    $found = false;
    foreach ($users as $row) {
        if ((int)$row[0] === $user_id) {
           
            $newRow = [$user_id, $username, $firstname, $lastname, $password, $primary_email];
            fputcsv($fp_temp, $newRow);
            $found = true;
        } else {
            fputcsv($fp_temp, $row);
        }
    }

    fclose($fp_temp);

    if (!$found) {

        unlink($tempPath); 
        die('User không tồn tại. Bạn cần tạo user mới.');
    }

 
    if (!copy($tempPath, $csvPath)) {
        die('Không thể lưu dữ liệu vào users.csv');
    }

    header('Location: ../users/users.php');
    exit;
}


if (isset($_POST['btnCreateUser'])) {
    // Kiểm tra username không trùng
    foreach ($users as $row) {
        if ($row[1] === $username) {
            die('Username đã tồn tại. <a href="../users/formuserinfo.php?id=0">Quay lại</a>');
        }
    }

    // Tìm id lớn nhất hiện có
    $maxId = 0;
    foreach ($users as $row) {
        $idVal = intval($row[0]);
        if ($idVal > $maxId) $maxId = $idVal;
    }
    $newId = $maxId + 1;

    // Thêm user mới vào mảng
    $users[] = [$newId, $username, $firstname, $lastname, $password, $primary_email];

  
    if (($fp_temp = fopen($tempPath, 'w')) === false) {
        die('Không thể mở file temp để ghi.');
    }
    foreach ($users as $row) {
        fputcsv($fp_temp, $row);
    }
    fclose($fp_temp);

    
    if (!copy($tempPath, $csvPath)) {
        die('Không thể lưu dữ liệu vào users.csv');
    }

 
    header('Location: ../users/users.php');
    exit;
}

die('Yêu cầu không hợp lệ.');
?>
