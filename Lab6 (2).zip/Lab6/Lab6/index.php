<?php 
include_once "includes/opening.php"; 
define("PAGE_TITLE", "Index Page");
template_header();
?>

    <h2>Welcome to Lab6 Index Page</h2>
    <p>Đây là trang chính của hệ thống. Vui lòng chọn một chức năng trong menu phía trên.</p>

<?php 
template_footer();
?>
