<?php

require_once __DIR__ . '/../includes/functions.php';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="utf-8">
    <title>Danh sách Users</title>
</head>
<body>
    <h1>Danh sách Users</h1>
    <?php
    
        displayUsersWithLinkToForm(__DIR__ . '/../data/users.csv');
    ?>
</body>
</html>
