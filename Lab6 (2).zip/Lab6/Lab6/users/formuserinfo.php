<?php

require_once __DIR__ . '/../includes/functions.php';

$users = loadUsersFromCsv(__DIR__ . '/../data/users.csv');

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
} else {
    $id = 0;
}

$user = null;
if ($id !== 0) {
    foreach ($users as $u) {
  
        if ($u->user_id == $id) {
            $user = $u;
            break;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="utf-8">
    <title>Thông tin user</title>
</head>
<body>
    <h1>Thông tin người dùng</h1>

    <p><strong>ID:</strong> <?php echo htmlspecialchars($id, ENT_QUOTES, 'UTF-8'); ?></p>

    <form action="../controllers/user_controller.php" method="POST">
  
        <input type="hidden" name="user_id" value="<?php echo $user ? htmlspecialchars($user->user_id, ENT_QUOTES, 'UTF-8') : '0'; ?>">

 
        <p>
            <label>Firstname:</label><br>
            <input type="text" name="firstname" value="<?php echo $user ? htmlspecialchars($user->firstname, ENT_QUOTES, 'UTF-8') : ''; ?>">
        </p>


        <p>
            <label>Lastname:</label><br>
            <input type="text" name="lastname" value="<?php echo $user ? htmlspecialchars($user->lastname, ENT_QUOTES, 'UTF-8') : ''; ?>">
        </p>

        
        <p>
            <label>Username:</label><br>
            <input type="text" name="username" value="<?php echo $user ? htmlspecialchars($user->username, ENT_QUOTES, 'UTF-8') : ''; ?>">
        </p>

       
        <p>
            <label>Password:</label><br>
            <input type="password" name="password_input" value="<?php echo $user ? htmlspecialchars($user->password, ENT_QUOTES, 'UTF-8') : ''; ?>">
        </p>

        <p>
            <label>Re-enter Password:</label><br>
            <input type="password" name="password_check" value="<?php echo $user ? htmlspecialchars($user->password, ENT_QUOTES, 'UTF-8') : ''; ?>">
        </p>

   
        <p>
            <label>Primary Email:</label><br>
            <input type="email" name="primary_email" value="<?php echo $user ? htmlspecialchars($user->primary_email, ENT_QUOTES, 'UTF-8') : ''; ?>">
        </p>

       
        <?php if ($id !== 0): ?>
            <p><input type="submit" name="btnUpdateUser" value="Update user"></p>
        <?php else: ?>
            <p><input type="submit" name="btnCreateUser" value="Create user"></p>
        <?php endif; ?>
    </form>
</body>
</html>
