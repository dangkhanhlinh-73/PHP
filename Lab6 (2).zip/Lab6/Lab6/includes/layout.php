<?php 

function template_header() { ?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title><?php print constant('PAGE_TITLE'); ?></title>
   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" 
          integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" 
          crossorigin="anonymous">
    <style>
        body {
            background-color: #f8f9fa;
            margin: 0;
        }
        header {
            background-color: #0d6efd;
            color: white;
            padding: 15px;
            text-align: center;
            font-size: 1.5rem;
        }
        nav {
            background-color: #e9ecef;
            padding: 10px 0;
        }
        nav a {
            margin: 0 15px;
            color: #0d6efd;
            text-decoration: none;
            font-weight: 500;
        }
        nav a:hover {
            text-decoration: underline;
        }
        footer {
            background-color: #f1f1f1;
            text-align: center;
            padding: 15px;
            margin-top: 50px;
            border-top: 1px solid #ccc;
        }
        .container {
            margin-top: 30px;
        }
    </style>
</head>
<body>

    <header>
        My Header
    </header>

    <nav class="text-center">
        <a href="../index.php">Trang chủ</a>
        <a href="../users/users.php">Danh sách Users</a>
        <a href="../users/formuserinfo.php?id=0">Tạo User mới</a>
    </nav>

    <main class="container">
<?php } ?>


<?php 
function template_footer() { ?>
    </main>

    <footer>
        Copyright © <?php echo date('Y'); ?> - Lab6 System
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
            crossorigin="anonymous"></script>
</body>
</html>
<?php } ?>
