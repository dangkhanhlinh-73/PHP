<?php

include_once __DIR__ . "/layout.php";
include_once __DIR__ . "/functions.php";
?>
