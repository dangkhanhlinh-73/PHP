<?php

function loadUsersFromCsv($csvPath = __DIR__ . '/../data/users.csv') {
    $users = [];
    if (!file_exists($csvPath)) return $users;

    if (($fp = fopen($csvPath, 'r')) !== false) {
       
        while (($row = fgetcsv($fp, 0, ',', '"', '\\')) !== false) {
            // định dạng: user_id,username,firstname,lastname,password,primary_email
            if (count($row) >= 6) {
                $users[] = (object)[
                    'user_id' => $row[0],
                    'username' => $row[1],
                    'firstname' => $row[2],
                    'lastname' => $row[3],
                    'password' => $row[4],
                    'primary_email' => $row[5],
                ];
            }
        }
        fclose($fp);
    }

    return $users;
}


function displayUsersWithLinkToForm($csvPath = __DIR__ . '/../data/users.csv') {
    $users = loadUsersFromCsv($csvPath);

    echo '<table border="1" cellpadding="6" cellspacing="0">';
    echo '<thead><tr><th>ID</th><th>Username</th><th>Firstname</th><th>Lastname</th><th>Email</th></tr></thead>';
    echo '<tbody>';
    foreach ($users as $user) {
        $id = htmlspecialchars($user->user_id, ENT_QUOTES, 'UTF-8');
        $username = htmlspecialchars($user->username, ENT_QUOTES, 'UTF-8');
        $firstname = htmlspecialchars($user->firstname, ENT_QUOTES, 'UTF-8');
        $lastname = htmlspecialchars($user->lastname, ENT_QUOTES, 'UTF-8');
        $email = htmlspecialchars($user->primary_email, ENT_QUOTES, 'UTF-8');

        echo '<tr>';
        echo "<td>{$id}</td>";
        echo "<td><a href=\"formuserinfo.php?id={$id}\">{$username}</a></td>";
        echo "<td>{$firstname}</td>";
        echo "<td>{$lastname}</td>";
        echo "<td>{$email}</td>";
        echo '</tr>';
    }
    echo '</tbody>';
    echo '</table>';

    echo '<p><a href="formuserinfo.php?id=0"><button type="button">Create user</button></a></p>';
}
?>
