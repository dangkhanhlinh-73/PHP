<?php
// run composer dump-autoload

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASSWORD', '1234');	// your password
define('DB_NAME', 'users_schema');

?>