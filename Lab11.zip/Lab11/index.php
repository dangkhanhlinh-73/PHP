<?php

require_once __DIR__ . '/vendor/autoload.php';

// use App\Controllers\PostController;
use App\Controllers\UserController;

session_start();
// $controller = new PostController();
$controller1 = new UserController();

$action = $_GET['action'] ?? 'index';
// $postId = $_GET['id'] ?? null;
$id = $_GET['id'] ?? null;

switch ($action) {
    case 'index':
        // $controller->index();
        $controller1->index();
        break;
    case 'show':
        // $controller->show($postId);
        $controller1->show($id);
        break;
    case 'create':
        // $controller->create();
        $controller1->create();
        break;
    case 'update':
        // $controller->update($postId);
        $controller1->update($id);
        break;
    case 'delete':
        // $controller->delete($postId);
        $controller1->delete($id);
        break;
    default:
        echo '404 Not Found';
}
