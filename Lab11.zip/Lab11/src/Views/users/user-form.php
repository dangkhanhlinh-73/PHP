<?php ob_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f9f9f9;
        }
        h1 {
            text-align: center;
            color: #333;
        }
        form {
            width: 50%;
            margin: 0 auto;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        form label {
            display: block;
            margin-top: 15px;
            font-weight: bold;
        }
        form input[type="text"],
        form input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        form input[type="submit"] {
            margin-top: 20px;
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 4px;
            background-color: #4CAF50;
            color: white;
            font-size: 16px;
            cursor: pointer;
        }
        form input[type="submit"]:hover {
            background-color: #45a049;
        }
        .back-link {
            display: block;
            width: 50%;
            margin: 20px auto;
            text-align: center;
            text-decoration: none;
            color: #007BFF;
        }
        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <h1>User Form</h1>
    <form action="/index.php?action=<?= isset($user['id']) ? 'update&id=' . $user['id'] : 'create' ?>" method="post">
        
        <?php if (!empty($error)): ?>
            <div style="color: red; text-align: center; margin-bottom: 20px;">
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>
        
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" value="<?= isset($user['username']) ? htmlspecialchars($user['username']) : '' ?>" required>

        <label for="firstname">Firstname:</label>
        <input type="text" id="firstname" name="firstname" value="<?= isset($user['firstname']) ? htmlspecialchars($user['firstname']) : '' ?>">

        <label for="lastname">Lastname:</label>
        <input type="text" id="lastname" name="lastname" value="<?= isset($user['lastname']) ? htmlspecialchars($user['lastname']) : '' ?>">

        <label for="password_input">Password:</label>
        <input type="password" id="password_input" name="password_input" value="<?= isset($user['password_input']) ? htmlspecialchars($user['password_input']) : '' ?>">

        <label for="password_check">Confirm Password:</label>
        <input type="password" id="password_check" name="password_check" value="<?= isset($user['password_check']) ? htmlspecialchars($user['password_check']) : '' ?>">

        <label for="email">Email:</label>
        <input type="text" id="email" name="email" value="<?= isset($user['email']) ? htmlspecialchars($user['email']) : '' ?>">

        <input type="submit" value="<?= isset($user['id']) ? 'Update' : 'Create' ?>">
    </form>
    <a href="/index.php" class="back-link">Back to User List</a>
</body>
</html>
<?php $content = ob_get_clean(); ?>
<?php include(__DIR__ .  '/../../../templates/layout.php'); ?>
