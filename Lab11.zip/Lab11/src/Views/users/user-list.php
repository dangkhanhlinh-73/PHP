<?php ob_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User List</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f9f9f9;
        }
        h1 {
            text-align: center;
            color: #333;
        }
        .message {
            width: 80%;
            margin: 10px auto;
            padding: 10px;
            border: 1px solid #4CAF50;
            background-color: #d4edda;
            color: #155724;
            border-radius: 5px;
            text-align: center;
        }
        .user-list {
            width: 80%;
            margin: 0 auto;
            border-collapse: collapse;
        }
        .user-list th, .user-list td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        .user-list th {
            background-color: #4CAF50;
            color: white;
        }
        .user-list tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        .user-list tr:hover {
            background-color: #ddd;
        }
        .action-links a {
            margin: 0 5px;
            text-decoration: none;
            color: #007BFF;
        }
        .action-links a:hover {
            color: #0056b3;
            text-decoration: underline;
        }
        .add-user {
            display: block;
            width: 150px;
            margin: 20px auto;
            text-align: center;
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .add-user:hover {
            background-color: #45a0;
        }
    </style>
    <script>
        function confirmDelete(url) {
            if (confirm("Are you sure you want to delete this user?")) {
                window.location.href = url;
            }
        }
    </script>
</head>
<body>
    <h1>User List</h1>
    
    <?php 
        if (isset($_SESSION['message'])): ?>
            <div class="message">
                <?= $_SESSION['message'] ?>
            </div>
        <?php unset($_SESSION['message']); ?>
    <?php endif; ?>
    <table class="user-list">
        <thead>
            <tr>
                <th>STT</th>
                <th>Username</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            if (!empty($users) && is_array($users)): 
                foreach ($users as $index => $user): 
            ?>
                <tr>
                    <td><?= $index + 1 ?></td>
                    <td>
                        <a href="/index.php?action=show&id=<?= $user['id'] ?>">         
                            <?= htmlspecialchars($user['username']) ?>
                        </a>
                    </td>
                    <td class="action-links">
                        <a href="/index.php?action=update&id=<?= $user['id'] ?>">Edit</a>
                        <a>|</a>
                        <a href="javascript:void(0);" 
                           onclick="confirmDelete('/index.php?action=delete&id=<?= $user['id'] ?>')">Delete</a>
                    </td>
                </tr>
            <?php 
                endforeach; 
            else: 
            ?>
                <tr>
                    <td colspan="3" style="text-align:center; color:#666; padding:20px;">
                        Không có người dùng nào.
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    <a href="/index.php?action=create" class="add-user">Add User</a>
</body>
</html>
<?php $content = ob_get_clean(); ?>
<?php include (__DIR__ . '/../../../templates/layout.php'); ?>