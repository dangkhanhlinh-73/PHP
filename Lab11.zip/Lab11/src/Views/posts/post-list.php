<?php ob_start(); ?>

<h1>Post List</h1>

<?php if (!empty($posts) && is_iterable($posts)): ?>
    <ul style="list-style: none; padding: 0;">
        <?php foreach ($posts as $post): ?>
            <?php
            $id    = htmlspecialchars($post['id'] ?? '', ENT_QUOTES, 'UTF-8');
            $title = htmlspecialchars($post['title'] ?? 'No title', ENT_QUOTES, 'UTF-8');
            ?>
            <li style="padding: 12px 0; border-bottom: 1px dashed #ddd;">
                <strong>
                    <a href="/crud/index.php?action=show&id=<?= $id ?>">
                        <?= $title ?>
                    </a>
                </strong>
                <span style="margin-left: 30px; color: #888; font-size: 0.9em;">
                    <a href="/crud/index.php?action=update&id=<?= $id ?>">Edit</a> |
                    <a href="/crud/index.php?action=delete&id=<?= $id ?>" 
                       style="color: red;"
                       onclick="return confirm('Xóa bài « <?= addslashes($title) ?> »?')">Delete</a>
                </span>
            </li>
        <?php endforeach; ?>
    </ul>
<?php else: ?>
    <p>Chưa có bài viết nào.</p>
<?php endif; ?>

<p>
    <a href="/crud/index.php?action=create" 
       style="padding: 10px 15px; background: #5cb85c; color: white; text-decoration: none; border-radius: 4px;">
        + Add New Post
    </a>
</p>

<?php
$content = ob_get_clean();
include __DIR__ . '/../../../templates/layout.php';
?>