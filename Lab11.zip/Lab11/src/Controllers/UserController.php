<?php

namespace App\Controllers;

use App\Controller;
use App\Models\User;

class UserController extends Controller
{
    private $userModel;

    public function __construct()
    {
        $this->userModel = new User();
    }

    public function index()
    {
        // Fetch all posts and display them in a view
        $users = $this->userModel->getAllUsers();

        $this->render('users\user-list', ['users' => $users]);
    }

    public function show($id)
    {
        
        $user = $this->userModel->getUserById($id);

        $this->render('users\user-form', ['user' => $user]);

    }

    public function create()
    {
        // Handle form submission to create a new post
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Retrieve form data
            $username = $_POST['username'];
            $firstname = $_POST['firstname'];
            $lastname = $_POST['lastname'];
            $password_input = $_POST['password_input'];
            $password_check = $_POST['password_check'];
            $email = $_POST['email'];
            
            if ($this->userModel->isUsernameExists($username)) {
                // Gửi thông báo lỗi đến view
                $error = "Username bị trùng !!!";
                $this->render('users\user-form', ['user' => compact('username', 'firstname', 'lastname', 'email'), 'error' => $error]);
                return;
            }
            
            // Kiểm tra mật khẩu xác nhận
            if ($password_input !== $password_check) {
                $error = "Mật khẩu không trùng !!!";
                $this->render('users\user-form', ['user' => compact('username', 'firstname', 'lastname', 'email'), 'error' => $error]);
                return;
            }

            // Call the model to create a new post
            $this->userModel->createUser($username , $firstname, $lastname ,$password_input ,$password_check ,$email);
        }

        // Display the form to create a new post
        
        $this->render('users\user-form', ['user' => []]);

    }

    public function update($id)
    {
        // Handle form submission to update a post
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Retrieve form data
            $username = $_POST['username'];
            $firstname = $_POST['firstname'];
            $lastname = $_POST['lastname'];
            $password_input = $_POST['password_input'];
            $password_check = $_POST['password_check'];
            $email = $_POST['email'];
            
            // Call the model to update the post
            $this->userModel->updateUser($id, $username , $firstname, $lastname ,$password_input ,$password_check ,$email);
            $_SESSION['message'] = "User $username cập nhật thành công";
        }

        // Fetch the post data and display the form to update
        $user = $this->userModel->getUserById($id);
        
        $this->render('users\user-form', ['user' => $user]);
    }

    public function delete($id)
    {
        $this->userModel->deleteUser($id);
        
        $_SESSION['message'] = "Xóa thành công user có ID: {$id}";
        
        header('Location: /index.php');
        
    }
}