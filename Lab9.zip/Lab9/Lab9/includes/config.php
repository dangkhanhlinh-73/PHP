<?php
session_start();
require_once('../includes/opening.php'); 
?>