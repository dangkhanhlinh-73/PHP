<?php 
include 'user.php';
include 'opening.php';

/* -------------------------------------------------------------
   LOAD USERS
--------------------------------------------------------------*/
function loadUsers($conn) {
    $users = array();
    $sql = "SELECT * FROM users";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $user = new User(
                $row['id'],
                $row['username'],
                $row['firstname'],
                $row['lastname'],
                $row['password_input'],
                $row['password_check'],
                $row['email']
            );
            $users[] = $user;
        }
    }
    return $users; 
}

/* -------------------------------------------------------------
   HIỂN THỊ LIST USER CÓ LINK FORM
--------------------------------------------------------------*/
function displayUsersWithLinkToForm($conn) {
    $users = loadUsers($conn);

    echo '<table class="table table-striped table-bordered table-hover" style="width: 60%; margin: auto; border-radius: 10px;">';  
    echo '<thead class="table-dark"><tr><th class="text-center">Username</th></tr></thead>';

    foreach ($users as $user) {
        echo '<tr>';
        echo '<td class="text-center"><a href="formuserinfo.php?id=' . $user->getUserID() . '">' . $user->getUserName() . '</a></td>';
        echo '</tr>';
    }

    echo '<tr><td class="text-end">
            <a href="formuserinfo.php?id=0" class="btn btn-success btn-action">Create User</a>
          </td></tr>';

    echo '</table>';
}

/* -------------------------------------------------------------
   ARRAY TO HTML TABLE
--------------------------------------------------------------*/
function arrayToHTMLTable($array) {
    if (empty($array)) {
        return "<p>No data</p>";
    }

    $html = '<table class="table table-striped table-bordered table-hover" style="width: 60%; margin: auto; border-radius: 10px;">';
    $html .= '<thead class="table-dark"><tr>';

    foreach (array_keys($array[0]) as $key) {
        $html .= '<th class="text-center">' . htmlspecialchars($key) . '</th>';
    }

    $html .= '</tr></thead><tbody>';

    foreach ($array as $row) {
        $html .= '<tr>';
        foreach ($row as $cell) {
            $html .= '<td class="text-center">' . htmlspecialchars($cell) . '</td>';
        }
        $html .= '</tr>';
    }

    $html .= '</tbody></table>';

    return $html;
}

/* -------------------------------------------------------------
   DISPLAY USERS (ARRAY)
--------------------------------------------------------------*/
function display_users($conn) {
    $query = "SELECT * FROM users";
    $result = $conn->query($query);

    $users = [];
    while($row = $result->fetch_assoc()) {
        $users[] = $row;
    }

    echo arrayToHTMLTable($users);
}

/* -------------------------------------------------------------
   DISPLAY USERS + ACTION
--------------------------------------------------------------*/
function display_users_with_action($connection, $query_string_delete, $query_string_Update, $action_text_delete, $action_text_Update) {
    $query = "SELECT id, username, firstname, lastname, email, password_input FROM users";
    $result = $connection->query($query);

    if ($result->num_rows == 0) {
        echo "<p>No data</p>";
        return;
    }

    echo '<table class="table table-striped table-bordered table-hover" style="width: 80%; margin: auto; border-radius: 10px;">';
    echo '<thead class="table-dark">';
    echo '<tr>
            <th class="text-center">ID</th>
            <th class="text-center">Username</th>
            <th class="text-center">First Name</th>
            <th class="text-center">Last Name</th>
            <th class="text-center">Password</th>
            <th class="text-center">Email</th>
            <th class="text-center">Action</th>
          </tr>';
    echo '</thead><tbody>';

    while ($row = $result->fetch_assoc()) {
        echo '<tr>';
        echo '<td class="text-center">' . $row['id'] . '</td>';
        echo '<td class="text-center"><a href="formuserinfo.php?id=' . $row['id'] . '">' . $row['username'] . '</a></td>';
        echo '<td class="text-center">' . $row['firstname'] . '</td>';
        echo '<td class="text-center">' . $row['lastname'] . '</td>';
        echo '<td class="text-center">' . htmlspecialchars($row['password_input']) . '</td>';
        echo '<td class="text-center">' . $row['email'] . '</td>';
        
        echo '<td class="text-center">';
        echo '<a href="' . $query_string_delete . $row['id'] . '" class="btn btn-danger btn-action">' . $action_text_delete . '</a>';
        echo ' | ';
        echo '<a href="' . $query_string_Update . $row['id'] . '" class="btn btn-primary btn-action">' . $action_text_Update . '</a>';
        echo '</td>';

        echo '</tr>';
    }

    echo '</tbody>';
    echo '<tr><td colspan="7" class="text-end">
            <a href="formuserinfo.php?id=0" class="btn btn-success btn-action">Sign Up</a>
          </td></tr>';
    echo '</table>';
}

/* -------------------------------------------------------------
   GET ONE USER BY ID
--------------------------------------------------------------*/
function get_row_by_id($conn, $table_name, $id){
    $sql = "SELECT * FROM $table_name WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $result = $stmt->get_result();
    return mysqli_fetch_array($result, MYSQLI_ASSOC);
}

/* -------------------------------------------------------------
   FORM TẠO / SỬA USER (đã sửa sạch lỗi PHP 8+)
--------------------------------------------------------------*/
function load_form_user(
    $id,
    $username = "",
    $firstname = "",
    $lastname = "",
    $password_input = "",
    $password_check = "",
    $email = "",
    $actionText = "Create"
) {
    ?>
    <div class="user-info" style="width: 50%; margin: auto; background: white; border-radius: 10px; 
         box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2); padding: 30px; margin-top: 30px;">

        <h2 class="text-center" style="color: #4e54c8; margin-bottom: 20px;">
            <?= $id != 0 ? "Edit User Information" : "Create New User" ?>
        </h2>
        
        <form action="../controllers/user_controller.php" method="POST">
            <input type="hidden" name="user_id" value="<?= $id ?>" />

            <div class="mb-3">
                <label class="form-label" style="font-weight: bold;">Username</label>
                <input type="text" class="form-control" name="username"
                       value="<?= htmlspecialchars($username ?? '', ENT_QUOTES) ?>" required>
            </div>

            <div class="mb-3">
                <label class="form-label" style="font-weight: bold;">First Name</label>
                <input type="text" class="form-control" name="firstname"
                       value="<?= htmlspecialchars($firstname ?? '', ENT_QUOTES) ?>" required>
            </div>

            <div class="mb-3">
                <label class="form-label" style="font-weight: bold;">Last Name</label>
                <input type="text" class="form-control" name="lastname"
                       value="<?= htmlspecialchars($lastname ?? '', ENT_QUOTES) ?>" required>
            </div>

            <div class="mb-3">
                <label class="form-label" style="font-weight: bold;">Password</label>
                <input type="password" class="form-control" name="password_input"
                       value="<?= htmlspecialchars($password_input ?? '', ENT_QUOTES) ?>" required>
            </div>

            <div class="mb-3">
                <label class="form-label" style="font-weight: bold;">Confirm Password</label>
                <input type="password" class="form-control" name="password_check"
                       value="<?= htmlspecialchars($password_check ?? '', ENT_QUOTES) ?>" required>
            </div>

            <div class="mb-3">
                <label class="form-label" style="font-weight: bold;">Primary Email</label>
                <input type="email" class="form-control" name="primary_email"
                       value="<?= htmlspecialchars($email ?? '', ENT_QUOTES) ?>" required>
            </div>

            <div class="text-center mt-4">
                <button type="submit" 
                        class="btn btn-success btn-action" 
                        name="<?= $id != 0 ? 'btnUpdateUser' : 'btnCreateUser' ?>" 
                        style="background-color: #28a745; color: white; border-radius: 50px; width: 45%; margin-right: 5px;">
                    <?= $actionText ?> User
                </button>

                <a href="users.php" class="btn btn-primary btn-action" 
                   style="border-radius: 50px; width: 45%; background-color: #4e54c8; color: white;">
                    Back
                </a>
            </div>
        </form>
    </div>
    <?php
}
?>
