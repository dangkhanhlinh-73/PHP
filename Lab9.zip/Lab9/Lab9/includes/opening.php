<?php
$server = "localhost"; // Địa chỉ MySQL
$username = "root"; // Tên đăng nhập MySQL
$password = "1234"; // Mật khẩu MySQL
$schema = "users_schema"; // Tên schema
// Kết nối đến cơ sở dữ liệu
$conn = new mysqli($server, $username, $password, $schema);
// $conn là đối tượng thuộc lớp mysqli, sử dụng để kết nối đến CSDL MySQL, biến này lưu trữ thông tin
//kết nối, bao gồm địa chỉ sever, username, pass, schema, khi khởi tạo thành công, biến này cho phép
//Thực hiện các truy vấn SQL trên CSDL đã kết nối

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}
?>