<?php
require_once('../includes/functions.php');
require_once('../includes/user.php');
require_once('../includes/config.php');

session_start();

/* ==========================
   DELETE USER
========================== */
if (isset($_GET['delete_user_id'])) {
    $user_id = intval($_GET['delete_user_id']);
    $delete_query = "DELETE FROM users WHERE id = $user_id";

    if ($conn->query($delete_query)) {
        $_SESSION['delete_user_id'] = $user_id;
        header("Location: ../Users/users.php");
        exit();
    } else {
        echo "ERROR";
    }

    exit();
}


/* ==========================
   CREATE / UPDATE USER
========================== */

if (isset($_POST["user_id"])) {

    $id = intval($_POST["user_id"]);
    $username = trim($_POST["username"]);
    $firstname = trim($_POST["firstname"]);
    $lastname = trim($_POST["lastname"]);
    $password_input = trim($_POST["password_input"]);
    $password_check = trim($_POST["password_check"]);
    $email = trim($_POST["primary_email"]);  // FIXED (email bị thiếu trước đây)

    $users = loadUsers($conn);

    /* ------------------------------
        LẤY DANH SÁCH USERNAME + EMAIL
    ------------------------------ */
    $existingUsernames = [];
    $existingEmails = [];

    foreach ($users as $u) {
        $existingUsernames[] = $u->getUserName();
        $existingEmails[] = $u->getPrimaryEmail();
    }

    /* ================================================================
        UPDATE USER
    ================================================================ */
    if ($id !== 0) {

        // Kiểm tra trùng username/email TRỪ user hiện tại
        foreach ($users as $u) {
            if ($u->getUserID() != $id) {
                if ($u->getUserName() === $username) {
                    header("Location: ../Users/formuserinfo.php?id=$id&error=" . urlencode("Username đã tồn tại!"));
                    exit();
                }
                if ($u->getPrimaryEmail() === $email) {
                    header("Location: ../Users/formuserinfo.php?id=$id&error=" . urlencode("Email đã tồn tại!"));
                    exit();
                }
            }
        }

        // UPDATE DB
        $stmt = $conn->prepare("
            UPDATE users 
            SET username=?, firstname=?, lastname=?, password_input=?, password_check=?, email=? 
            WHERE id=?
        ");
        $stmt->bind_param("ssssssi", 
            $username, $firstname, $lastname, 
            $password_input, $password_check, 
            $email, $id
        );

        if (!$stmt->execute()) {
            echo "ERROR UPDATE: " . $stmt->error;
        } else {
            $_SESSION['notification'] = "user-updated";
            header("Location: ../Users/users.php");
            exit();
        }

        $stmt->close();
    }

    /* ================================================================
        CREATE NEW USER
    ================================================================ */
    else {

        // Tạo ID mới
        $newID = 1;
        foreach ($users as $u) {
            if ($u->getUserID() >= $newID) {
                $newID = $u->getUserID() + 1;
            }
        }

        // Check trùng username
        if (in_array($username, $existingUsernames)) {
            header('Location: ../Users/formuserinfo.php?id=0&error=' . urlencode("Username đã tồn tại!"));
            exit();
        }

        // Check trùng email
        if (in_array($email, $existingEmails)) {
            header('Location: ../Users/formuserinfo.php?id=0&error=' . urlencode("Email đã tồn tại!"));
            exit();
        }

        // INSERT
        $stmt = $conn->prepare("
            INSERT INTO users(id, username, firstname, lastname, password_input, password_check, email)
            VALUES (?,?,?,?,?,?,?)
        ");
        $stmt->bind_param("issssss",
            $newID, $username, $firstname, $lastname, 
            $password_input, $password_check, $email
        );

        if (!$stmt->execute()) {
            echo "ERROR INSERT: " . $stmt->error;
        } else {
            $_SESSION['notification'] = "user-created";
            header("Location: ../Users/users.php");
            exit();
        }

        $stmt->close();
    }
}
?>
