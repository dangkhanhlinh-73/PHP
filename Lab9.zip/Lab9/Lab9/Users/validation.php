<?php
require_once('../includes/config.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Truy vấn kiểm tra username và password
    $sql = "SELECT * FROM users WHERE username = ? AND password_input = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ss', $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Đăng nhập thành công
        $_SESSION['username'] = $username;
        echo "You have logged in successfully.";
        header('Location: ../Users/users.php'); 
    } else {
        $_SESSION['login_error'] = "Thông tin không chính xác, vui lòng nhập lại !!";
        header('Location: login.php'); // Chuyển hướng về form đăng nhập
        exit();
    }
}
?>