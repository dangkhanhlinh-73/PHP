<?php
require_once('../includes/config.php');

function template_header() { ?>
    <!DOCTYPE html>
    <html lang="vi">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>My Website</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
        <style>
            /* Global Styles */
            body, html {
                height: 100%;
                margin: 0;
                background: linear-gradient(135deg, #4e54c8, #8f94fb);
                color: #333;
                font-family: Arial, sans-serif;
            }

            /* Navbar Styles */
            .navbar {
                background: rgba(78, 84, 200, 0.9);
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            }

            .navbar-brand, .nav-link {
                color: white !important;
                font-weight: bold;
                transition: color 0.3s ease, transform 0.3s ease;
                text-transform: uppercase; /* Đổi chữ thành hoa */
                font-size: 16px; /* Tăng kích thước chữ */
                white-space: nowrap; /* Đảm bảo không bị xuống dòng */
            }

            .navbar-brand:hover, .nav-link:hover {
                color: #c9c9ff !important;
                transform: scale(1.1); /* Tạo hiệu ứng phóng to khi hover */
            }

            /* Khi menu bị thu gọn trên di động */
            .navbar-collapse {
                flex-grow: 0;
            }

            .navbar-nav {
                display: flex;
                flex-direction: row;
                gap: 1rem; /* Giãn cách giữa các mục */
            }

            /* Navbar Toggler */
            .navbar-toggler {
                border-color: rgba(255, 255, 255, 0.3); /* Tùy chỉnh màu của icon toggle */
            }

            .navbar-toggler-icon {
                background-color: white; /* Đổi màu icon thành trắng */
            }

            /* Footer Styles */
            footer {
                background: rgba(78, 84, 200, 0.9);
                color: white;
                padding: 20px 0;
                text-align: center;
                box-shadow: 0 -4px 8px rgba(0, 0, 0, 0.1);
            }
            footer a {
                color: #c9c9ff;
                text-decoration: none;
                transition: color 0.3s ease;
            }
            footer a:hover {
                color: #ffffff;
            }
        </style>
    </head>
    <body>
        <!-- Navigation Bar -->
        <nav class="navbar navbar-expand-lg">
            <div class="container">
                <a class="navbar-brand" href="#">
                    <?php
                    if (isset($_SESSION['username'])) {
                        echo "Xin chào, " . htmlspecialchars($_SESSION['username']);
                    } else {
                        echo "Xin chào bạn!";
                    }
                    ?>
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                    <?php if (isset($_SESSION['username'])) { ?>
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Trang chủ</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Về chúng tôi</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Liên hệ</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Dịch vụ</a>
                        </li>
                            <li class="nav-item">
                                <a class="nav-link" href="logout.php">Đăng xuất</a>
                            </li>
                        <?php } ?>
                    </ul>
                </div>
            </div>
        </nav>
<?php } ?>

<?php
function template_footer() { ?>
        <!-- Footer -->
        <footer class="mt-5">
            <div>&copy; 2024 My Website | <a href="#" class="text-white">Chính sách bảo mật</a></div>
        </footer>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    </body>
    </html>
<?php } ?>
