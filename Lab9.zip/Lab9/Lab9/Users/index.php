<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trang Chào Mừng</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body, html {
            height: 100%;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #4e54c8, #8f94fb);
            font-family: Arial, sans-serif;
            color: #333;
        }
        .welcome-container {
            max-width: 400px;
            text-align: center;
            padding: 40px;
            border-radius: 15px;
            background-color: #fff;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
            transform: scale(0.9);
            transition: transform 0.3s ease;
        }
        .welcome-container:hover {
            transform: scale(1);
        }
        .welcome-container h1 {
            font-size: 2em;
            font-weight: 700;
            color: #4e54c8;
        }
        .welcome-container p {
            font-size: 1.1em;
            color: #666;
            margin-bottom: 1.5em;
        }
        .welcome-container a.btn-primary {
            font-size: 1.1em;
            padding: 0.6em 2em;
            border-radius: 50px;
            box-shadow: 0 4px 10px rgba(78, 84, 200, 0.3);
            transition: background-color 0.3s ease, box-shadow 0.3s ease;
        }
        .welcome-container a.btn-primary:hover {
            background-color: #3538c7;
            box-shadow: 0 6px 15px rgba(78, 84, 200, 0.5);
        }
    </style>
</head>
<body>
    <div class="welcome-container">
        <h1>Chào mừng đến với hệ thống</h1>
        <p>Để trải nghiệm đầy đủ, vui lòng <a href="login.php" class="btn btn-primary">Đăng nhập</a>.</p>
    </div>
</body>
</html>
