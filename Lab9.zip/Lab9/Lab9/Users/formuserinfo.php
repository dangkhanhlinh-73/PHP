<?php

require_once('../includes/functions.php');
require_once('../includes/config.php');
include 'layout.php';
template_header();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Information</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .user-info {
            background-color: #f8f9fa;
            border-radius: 5px; 
            padding: 20px; 
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2); 
            margin-top: 20px;
        }
        .user-info h2 {
            color: #28a745; 
        }

        .form-actions {
            display: flex;
            justify-content: space-between; /* Giúp căn 2 nút về hai phía */
            margin-top: 20px;
        }

        .back-button {
            background-color: #007bff; /* Màu xanh cho nút quay về */
            color: white;
            text-decoration: none;
            padding: 7px 16px;
            border-radius: 10px;
        }

        .button-group {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }
    </style>
</head>
<body>

<div class="container mt-5">
    <?php

    if (isset($_GET['error'])) {
        echo '<div class="alert alert-danger">' . htmlspecialchars($_GET['error']) . '</div>';
    }

    
    if (isset($_GET['id'])) {
    $id = $_GET['id'];
    if ($id == 0) {
        load_form_user($id, null, null, null, null, null, null, 'Create');
    } else {
        $user = get_row_by_id($conn, 'users', $id);
        if ($user) {
            load_form_user($id, $user['username'], $user['firstname'], $user['lastname'], $user['password_input'], $user['password_check'], $user['email'], 'Update');
        } else {
            echo "<div class='alert alert-danger'>User not found.</div>";
        }
    }
}
    ?>

</div>

<!-- Bootstrap JS and dependencies -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php template_footer(); ?>