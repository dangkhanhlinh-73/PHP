<?php 
include 'layout.php';
require_once('../includes/config.php');
require_once('../includes/functions.php');
template_header();
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Danh Sách Người Dùng</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body, html {
            height: 100%;
            margin: 0;
            background: linear-gradient(135deg, #4e54c8, #8f94fb);
            font-family: Arial, sans-serif;
            color: #333;
            display: flex;
            flex-direction: column;
        }
        main {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding-top: 20px;
        }
        .header-bg {
            background-color: #4e54c8; 
            color: white; 
            padding: 15px;
            border-radius: 10px; 
            text-align: center; 
            width: 60%;
            margin-bottom: 20px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        }
        .alert-custom {
            border-radius: 8px;
            padding: 15px;
            text-align: center;
            font-weight: bold;
        }
        .alert-success {
            background-color: #28a745;
            color: white;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .alert-danger {
            background-color: #dc3545;
            color: white;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .btn-action {
            border-radius: 50px;
            font-size: 0.9em;
            padding: 0.5em 1.5em;
            transition: background-color 0.3s ease;
            color: white;
        }
        .btn-delete {
            background-color: #dc3545;
        }
        .btn-update {
            background-color: #28a745;
        }
        .btn-delete:hover {
            background-color: #b02a37;
        }
        .btn-update:hover {
            background-color: #218838;
        }
        table {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            width: 80%;
        }
        table th, table td {
            padding: 12px;
            text-align: center;
        }
        table th {
            background-color: #4e54c8;
            color: white;
        }
    </style>
</head>
<body>

<main class="container mt-5">
    <h1 class="header-bg">Danh sách người dùng</h1>
    <?php 
        if (isset($_SESSION['notification'])) {
            $action = $_SESSION['notification'];
            if ($action == 'user-updated') {
                echo '<div class="alert alert-success alert-custom" role="alert">Người dùng đã được cập nhật thành công.</div>';
            } elseif ($action == 'user-created') {
                echo '<div class="alert alert-success alert-custom" role="alert">Người dùng mới đã được tạo thành công.</div>';
            }
            // Xóa thông báo khỏi session để không hiển thị lại sau khi refresh
            unset($_SESSION['notification']);
        }

        if (isset($_SESSION['delete_user_id'])) {
            $deleted_id = $_SESSION['delete_user_id'];
            echo '<div class="alert alert-danger alert-custom" role="alert">Người dùng có ID: ' . htmlspecialchars($deleted_id) . ' đã bị xóa.</div>';
            unset($_SESSION['delete_user_id']);
        }
    ?>
            <?php 
                // Hàm này sẽ hiển thị danh sách người dùng với các nút hành động
                display_users_with_action($conn, "../controllers/user_controller.php?delete_user_id=", "formuserinfo.php?id=", "Delete", "Update");
            ?>
        
   
</main>

<footer>
    <?php template_footer(); ?>
</footer>

<!-- Bootstrap JS and dependencies -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
