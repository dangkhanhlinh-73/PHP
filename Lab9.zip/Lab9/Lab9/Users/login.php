<?php 
include 'layout.php';
template_header();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng nhập</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body, html {
            height: 100%;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #4e54c8, #8f94fb);
            font-family: Arial, sans-serif;
        }
        .login-container {
            max-width: 400px;
            width: 100%;
            background-color: #fff;
            border-radius: 15px;
            padding: 40px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
            text-align: center;
        }
        .login-container h1 {
            font-size: 2em;
            font-weight: bold;
            color: #4e54c8;
            margin-bottom: 20px;
        }
        .login-container .form-label {
            font-weight: bold;
            color: #333;
        }
        .btn-login {
            font-size: 1.1em;
            padding: 0.6em 0;
            width: 100%;
            border-radius: 50px;
            background-color: #4e54c8;
            color: #fff;
            box-shadow: 0 4px 10px rgba(78, 84, 200, 0.3);
            transition: background-color 0.3s ease, box-shadow 0.3s ease;
        }
        .btn-login:hover {
            background-color: #3538c7;
            box-shadow: 0 6px 15px rgba(78, 84, 200, 0.5);
        }
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border-color: #f5c6cb;
            border-radius: 8px;
            padding: 10px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <?php 
            if (isset($_SESSION['login_error'])) {
                echo "<div class='alert alert-danger'>" . $_SESSION['login_error'] . "</div>";
                unset($_SESSION['login_error']); 
            }
        ?>
        <h1>Đăng nhập</h1>
        <form action="validation.php" method="POST">
            <div class="mb-3">
                <label for="username" class="form-label">Tên đăng nhập</label>
                <input type="text" class="form-control" id="username" name="username" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Mật khẩu</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <button type="submit" class="btn btn-login">Đăng nhập</button>
        </form>
    </div>

<!-- Bootstrap JS and dependencies -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
