<?php

require_once __DIR__ . '/vendor/autoload.php';

use App\Controllers\PostController;
use App\Controllers\UserController;

// Database connection using MySQLi
$host = 'localhost';
$username = 'root';
$password = '1234';
$dbname = 'users_schema';

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

// Instantiate the controller with the MySQLi connection
$postController = new PostController($conn);

// Call the view method to display the list of posts
$userController = new UserController($conn);
$postController->index();

// Call the view method to display the list of posts
$userController->view();

// Close the MySQLi connection
$conn->close();