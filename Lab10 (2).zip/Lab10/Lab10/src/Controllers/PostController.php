<?php

namespace App\Controllers;

use App\Models\Post;

class PostController
{
    private $connection;

    public function __construct($connection)
    {
        $this->connection = $connection;
    }

    public function view()
    {
        // Lấy dữ liệu từ DB
        $posts = Post::getAllPosts($this->connection);

        // Truyền biến vào view (rất quan trọng!)
        $title = 'Posts';
        extract(compact('posts', 'title'));

        // Load view
        include(__DIR__ . '/../Views/posts/index.php');
    }

    public function index()
    {
        // Dữ liệu mẫu (hoặc có thể lấy từ DB)
        $posts = [
            new Post(1, 'Title 1', 'Content 1'),
            new Post(2, 'Title 2', 'Content 2'),
            new Post(3, 'Bài viết thứ 3', 'Nội dung bài 3 đây nè...'),
        ];

        // Truyền biến vào view
        $title = 'Posts';
        extract(compact('posts', 'title'));

        // Load view
        include(__DIR__ . '/../Views/posts/index.php');
    }
}