<?php

namespace App\Controllers;

use App\Models\User;

class UserController
{
    private $connection;

    public function __construct($connection)
    {
        $this->connection = $connection;
    }

    public function view()
    {
        // Lấy tất cả users từ database
        $users = User::getAllUsers($this->connection);

        // TRUYỀN BIẾN VÀO VIEW (bắt buộc phải có 3 dòng này)
        $title = 'Users';
        extract(compact('users', 'title'));  // Đây là dòng cứu mạng!

        // Load view
        include(__DIR__ . '/../Views/users/index.php');
    }
}