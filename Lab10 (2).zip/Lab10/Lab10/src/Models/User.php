<?php
namespace App\Models;
class User  
{
    private $userID;
    private $userName;
    private $firstName;
    private $lastName;
    private $passwordInput;
    private $passwordCheck;
    private $primaryEmail;

    public function __construct($userID, $userName, $firstName, $lastName, $passwordInput, $passwordCheck, $primaryEmail)
    {
        $this->userID = $userID;
        $this->userName = $userName;
        $this->firstName = $firstName;
        $this->lastName = $lastName;
        $this->passwordInput = $passwordInput;
        $this->passwordCheck = $passwordCheck;
        $this->primaryEmail = $primaryEmail;
        
    }

    public function getUserID()
    {
        return $this->userID;
    }

    public function getUserName()
    {
        return $this->userName;
    }

    public function getFirstName()
    {
        return $this->firstName;
    }
    public function getLastName()
    {
        return $this->lastName;
    }
    public function getPasswordInput()
    {
        return $this->passwordInput;
    }
    public function getPasswordCheck()
    {
        return $this->passwordCheck;
    }
    public function getPrimaryEmail()
    {
        return $this->primaryEmail;
    }

    public static function getAllUsers($mysqli)
    {
        $result = $mysqli->query("SELECT * FROM users");

        $users = [];
        while ($row = $result->fetch_assoc()) {
            $users[] = new User(
                $row['id'],
                 $row['username'],
                  $row['firstname'],
                   $row['lastname'],
                    $row['password_input'],
                     $row['password_check'],
                      $row['email']);
        }

        return $users;
    }
}

?>