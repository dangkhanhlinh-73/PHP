<?php

namespace App\Models;

class Post
{
    private $id;
    private $title;
    private $content;

    public function __construct($id, $title, $content)
    {
        $this->id = $id;
        $this->title = $title;
        $this->content = $content;
    }

    // Getters and setters here
    public function getId()
    {
        return $this->id;
    }

    public function getTitle()
    {
        return $this->title;
    }

    public function getContent()
    {
        return $this->content;
    }

    // Database operations using MySQLi
    public static function getAllPosts($mysqli)
    {
        $result = $mysqli->query("SELECT * FROM posts");

        $posts = [];
        while ($row = $result->fetch_assoc()) {
            $posts[] = new Post($row['id'], $row['title'], $row['content']);
        }

        return $posts;
    }

}