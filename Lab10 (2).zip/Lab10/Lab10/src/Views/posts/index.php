<?php 
$title = $title ?? 'Posts';
$posts = $posts ?? []; 
?>

<?php ob_start(); ?>

<h1><?= htmlspecialchars($title) ?></h1>

<?php if (empty($posts)): ?>
    <div class="alert alert-info text-center p-4">
        <strong>Chưa có bài viết nào.</strong>
    </div>
<?php else: ?>
    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
        <?php foreach ($posts as $post): ?>
            <div class="col">
                <div class="card h-100 shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title text-primary">
                            <?= htmlspecialchars($post->getTitle()) ?>
                        </h5>
                        <p class="card-text text-muted">
                            <?= nl2br(htmlspecialchars(substr($post->getContent(), 0, 150))) ?>
                            <?= strlen($post->getContent()) > 150 ? '...' : '' ?>
                        </p>
                    </div>
                    <div class="card-footer bg-white text-end">
                        <button class="btn btn-outline-primary btn-sm">Edit</button>
                        <button class="btn btn-outline-danger btn-sm">Delete</button>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php $content = ob_get_clean(); ?>
<?php include(__DIR__ . '/../../../templates/layout.php'); ?>