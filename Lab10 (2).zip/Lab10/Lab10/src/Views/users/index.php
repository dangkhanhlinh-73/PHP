<?php 
$title = $title ?? 'Users';
$users = $users ?? []; 
?>

<?php ob_start(); ?>

<h1><?= htmlspecialchars($title) ?></h1>

<?php if (empty($users)): ?>
    <div class="alert alert-info text-center p-4">
        Chưa có người dùng nào trong hệ thống.
    </div>
<?php else: ?>
    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
        <?php foreach ($users as $user): ?>
            <div class="col">
                <div class="card h-100 shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title text-primary">
                            ID: <?= htmlspecialchars($user->getUserID()) ?>
                        </h5>
                        <h6 class="text-dark fw-bold">
                            <?= htmlspecialchars($user->getUserName()) ?>
                        </h6>
                        <hr class="my-2">
                        <p class="mb-1"><strong>Họ:</strong> <?= htmlspecialchars($user->getFirstName() ?? 'N/A') ?></p>
                        <p class="mb-1"><strong>Tên:</strong> <?= htmlspecialchars($user->getLastName() ?? 'N/A') ?></p>
                        <p class="mb-0"><strong>Email:</strong> <?= htmlspecialchars($user->getPrimaryEmail() ?? 'Chưa có') ?></p>
                    </div>
                    <div class="card-footer bg-white text-end">
                        <button class="btn btn-outline-primary btn-sm">Edit</button>
                        <button class="btn btn-outline-danger btn-sm">Delete</button>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php $content = ob_get_clean(); ?>
<?php include(__DIR__ . '/../../../templates/layout.php'); ?>